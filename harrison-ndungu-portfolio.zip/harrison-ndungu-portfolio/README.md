# Harrison Ndung'u - Portfolio Website

This repository contains the source code for the personal portfolio website of Harrison Ndung'u.

## File Structure
- `index.html`: Main HTML file
- `style.css`: Stylesheet
- `script.js`: Interactive JavaScript code
- `.nojekyll`: Prevents GitHub Pages from ignoring files beginning with an underscore
- `assets/`: Image assets (profile picture, workshop pictures)

## Deployment
Hosted on GitHub Pages / custom hosting.
