document.addEventListener("DOMContentLoaded", () => {
    console.log("Welcome to Harrison Ndung'u's portfolio site!");
});
